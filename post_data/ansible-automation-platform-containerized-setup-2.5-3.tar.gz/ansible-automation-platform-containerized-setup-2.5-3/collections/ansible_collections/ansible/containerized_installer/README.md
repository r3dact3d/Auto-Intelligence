# AAP containerized installer

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![pipeline status](https://gitlab.cee.redhat.com/ansible/aap-containerized-installer/badges/main/pipeline.svg)](https://gitlab.cee.redhat.com/ansible/aap-containerized-installer/-/commits/main)
[![Latest Release](https://gitlab.cee.redhat.com/ansible/aap-containerized-installer/-/badges/release.svg)](https://gitlab.cee.redhat.com/ansible/aap-containerized-installer/-/releases)

# Table of Contents
* [Requirements](#requirements)
* [Collections](#collections)
* [Configuration](#configuration)
   * [Common](#common)
   * [Images](#images)
   * [Automation Controller](#automation-controller)
   * [Automation EDA](#automation-eda)
   * [Automation Gateway](#automation-gateway)
   * [Automation Hub](#automation-hub)
   * [Database](#database)
   * [Receptor](#receptor)
   * [Redis](#redis)
* [Usage](#usage)
   * [Online install](#online-install)
   * [Offine install](#offline-install)
   * [Backup](#backup)
   * [Restore](#restore)
   * [Uninstall](#uninstall)
* [Access](#access)

## Requirements

- ansible-core

```bash
$ dnf install ansible-core
or
$ pip install --user ansible-core
```

## Collections

The ansible collections used by the installer can be found in the `requirements.yml` file.

- ansible.controller (optional)
- ansible.posix
- community.crypto
- community.postgresql
- containers.podman (>= 1.10.0)
- infra.ah_configuration
- infra.controller_configuration

```bash
$ ansible-galaxy collection install -r requirements.yml
```

Finally, install the `ansible.containerized_installer` collection by running:

```bash
$ ansible-galaxy collection install .
```

## Configuration

### Common

| Name                  | Description                 | Required | Optional | Default                        |
| --------------------- | --------------------------- | -------- | -------- | ------------------------------ |
| bundle_dir            | Bundle directory            |          |    x     | false                          |
| bundle_install        | Use offline installation    |          |    x     | false                          |
| ca_tls_cert           | TLS CA certificate          |          |    x     |                                |
| ca_tls_key            | TLS CA key                  |          |    x     |                                |
| ca_tls_key_passphrase | TLS CA key passphrase       |          |    x     |                                |
| ca_tls_remote         | TLS CA remote files         |          |    x     | false                          |
| container_compress    | Container compress software |          |    x     | gzip                           |
| container_keep_images | Keep container images       |          |    x     | false                          |
| container_pull_images | Pull newer container images |          |    x     | true                           |
| custom_ca_cert        | Custom TLS CA certificate   |          |    x     |                                |
| registry_auth         | Use registry authentication |          |    x     | true                           |
| registry_ns_aap       | AAP registry namespace      |          |    x     | ansible-automation-platform-25 |
| registry_ns_rhel      | RHEL registry namespace     |          |    x     | rhel8                          |
| registry_tls_verify   | Verify registry TLS         |          |    x     | true                           |
| registry_url          | The registry URL            |          |    x     | registry.redhat.io             |
| registry_username     | The registry username       |          |    x     |                                |
| registry_password     | The registry password       |          |    x     |                                |

### Images

| Name               | Description                           | Required | Optional | Default                        |
| ------------------ | ------------------------------------- | -------- | -------- | ------------------------------ |
| controller_image   | Automation Controller image           |          |    x     | controller-rhel8:latest        |
| de_extra_images    | Decision Environment extra images     |          |    x     | []                             |
| de_supported_image | Decision Environment supported image  |          |    x     | de-supported-rhel8:latest      |
| eda_image          | Automation EDA image                  |          |    x     | eda-controller-rhel8:latest    |
| eda_web_image      | Automation EDA web image              |          |    x     | eda-controller-ui-rhel8:latest |
| ee_extra_images    | Execution Environment extra images    |          |    x     | []                             |
| ee_minimal_image   | Execution Environment minimal image   |          |    x     | ee-minimal-rhel8:latest        |
| ee_supported_image | Execution Environment supported image |          |    x     | ee-supported-rhel8:latest      |
| hub_image          | Automation Hub image                  |          |    x     | hub-rhel8:latest               |
| hub_web_image      | Automation Hub web image              |          |    x     | hub-web-rhel8:latest           |
| pcp_image          | Performance Co-Pilot image            |          |    x     | pcp:latest                     |
| postgresql_image   | Postgresql image                      |          |    x     | postgresql-15:latest           |
| receptor_image     | Receptor image                        |          |    x     | receptor-rhel8:latest          |
| redis_image        | Redis image                           |          |    x     | redis-6:latest                 |

### Automation Controller

| Name                                  | Description                                   | Required | Optional | Default            |
| ------------------------------------- | --------------------------------------------- | -------- | -------- | ------------------ |
| controller_admin_password             | Automation Controller admin password          |     x    |          |                    |
| controller_admin_user                 | Automation Controller admin user              |          |    x     | admin              |
| controller_event_workers              | Automation Controller event workers           |          |    x     |  4                 |
| controller_license_file               | Automation Controller license file            |          |    x     |                    |
| controller_nginx_client_max_body_size | Nginx maximum body size                       |          |    x     | 5m                 |
| controller_nginx_disable_hsts         | Disable Nginx HSTS                            |          |    x     | false              |
| controller_nginx_disable_https        | Disable Nginx HTTPS                           |          |    x     | false              |
| controller_nginx_hsts_max_age         | Nginx HSTS maximum age                        |          |    x     | 63072000           |
| controller_nginx_http_port            | Nginx HTTP port                               |          |    x     | 8080               |
| controller_nginx_https_port           | Nginx HTTPS port                              |          |    x     | 8443               |
| controller_nginx_https_protocols      | Nginx HTTPS protocols                         |          |    x     | [TLSv1.2, TLSv1.3] |
| controller_nginx_user_headers         | Custom Nginx headers                          |          |    x     | []                 |
| controller_pg_database                | Postgresql Controller database                |          |    x     | awx                |
| controller_pg_host                    | Postgresql Controller host                    |     x    |          |                    |
| controller_pg_password                | Postgresql Controller password                |     x    |          |                    |
| controller_pg_port                    | Postgresql Controller port                    |          |    x     | 5432               |
| controller_pg_socket                  | Postgresql Controller unix socket             |          |    x     |                    |
| controller_pg_username                | Postgresql Controller user                    |          |    x     | awx                |
| controller_postinstall                | Enable Controller postinstall                 |          |    x     | false              |
| controller_postinstall_dir            | Postinstall directory                         |          |    x     |                    |
| controller_secret_key                 | Automation Controller secret key              |          |    x     |                    |
| controller_tls_cert                   | Automation Controller TLS certificate         |          |    x     |                    |
| controller_tls_key                    | Automation Controller TLS key                 |          |    x     |                    |
| controller_tls_remote                 | Automation Controller TLS remote files        |          |    x     | false              |
| controller_uwsgi_listen_queue_size    | Automation Controller uwsgi listen queue size |          |    x     | 2048               |

#### Automation Controller - Postinstall

The controller postinstall allows one to create resources (projects, users, roles, etc..) after the controller deployment.
This requires the controller license to be installed first (see controller_license_file variable).

| Name                                 | Description                                 | Required | Optional | Default |
| ------------------------------------ | ------------------------------------------- | -------- | -------- | --------|
| controller_postinstall               | Enable Automation Controller postinstall    |          |     x    | false   |
| controller_postinstall_async_delay   | Postinstall delay between retries           |          |     x    | 1       |
| controller_postinstall_async_retries | Postinstall number of tries to attempt      |          |     x    | 30      |
| controller_postinstall_dir           | Automation Controller postinstall directory |          |     x    |         |
| controller_postinstall_ignore_files  | Automation Controller ignore files          |          |     x    | []      |
| controller_postinstall_repo_ref      | Automation Controller repository branch/tag |          |     x    | main    |
| controller_postinstall_repo_url      | Automation Controller repository URL        |          |     x    |         |

The `controller_postinstall_repo_url` variable can be used to define the postinstall repository URL which may include
authentication information.

- `http(s)://<host>/<repo>.git` (public repository without http(s) authentication)
- `http(s)://<user>:<password>@<host>:<repo>.git` (private repository with http(s) authentication)
- `git@<host>:<repo>.git` (public/private repository with ssh authentication)

When using ssh based authentication, the installer doesn't configure anything (ssh key or so) for you and you need
to have everything configured on the installer node.

### Automation EDA

| Name                           | Description                             | Required | Optional | Default            |
| ------------------------------ | --------------------------------------- | -------- | -------- | ------------------ |
| eda_activation_workers         | Automation EDA activation workers count |          |    x     | 2                  |
| eda_admin_password             | Automation EDA admin password           |     x    |          |                    |
| eda_debug                      | Automation EDA debug                    |          |    x     | false              |
| eda_main_url                   | Automation EDA main URL                 |          |    x     |                    |
| eda_max_running_activations    | Automation EDA max running activations  |          |    x     | 12                 |
| eda_nginx_client_max_body_size | Nginx maximum body size                 |          |    x     | 1m                 |
| eda_nginx_disable_hsts         | Disable Nginx HSTS                      |          |    x     | false              |
| eda_nginx_disable_https        | Disable Nginx HTTPS                     |          |    x     | false              |
| eda_nginx_hsts_max_age         | Nginx HSTS maximum age                  |          |    x     | 63072000           |
| eda_nginx_http_port            | Nginx HTTP port                         |          |    x     | 8082               |
| eda_nginx_https_port           | Nginx HTTPS port                        |          |    x     | 8445               |
| eda_nginx_https_protocols      | Nginx HTTPS protocols                   |          |    x     | [TLSv1.2, TLSv1.3] |
| eda_nginx_user_headers         | Custom Nginx headers                    |          |    x     | []                 |
| eda_pg_database                | Postgresql EDA database                 |          |    x     | eda                |
| eda_pg_host                    | Postgresql EDA host                     |     x    |          |                    |
| eda_pg_password                | Postgresql EDA password                 |     x    |          |                    |
| eda_pg_port                    | Postgresql EDA port                     |          |    x     | 5432               |
| eda_pg_socket                  | Postgresql EDA unix socket              |          |    x     |                    |
| eda_pg_username                | Postgresql EDA user                     |          |    x     | eda                |
| eda_redis_disable_tls          | Disable TLS Redis (for multiple nodes)  |          |    x     | false              |
| eda_redis_host                 | Redis EDA host (for multiple nodes)     |          |    x     |                    |
| eda_redis_password             | Redis EDA password (for multiple nodes) |          |    x     |                    |
| eda_redis_port                 | Redis EDA port (for multiple nodes)     |          |    x     | 6379               |
| eda_redis_tls_cert             | Automation EDA redis TLS certificate    |          |    x     |                    |
| eda_redis_tls_key              | Automation EDA redis TLS key            |          |    x     |                    |
| eda_redis_username             | Redis EDA username (for multiple nodes) |          |    x     | eda                |
| eda_safe_plugins               | Automation EDA safe plugins             |          |    x     | []                 |
| eda_secret_key                 | Automation EDA secret key               |          |    x     |                    |
| eda_tls_cert                   | Automation EDA TLS certificate          |          |    x     |                    |
| eda_tls_key                    | Automation EDA TLS key                  |          |    x     |                    |
| eda_tls_remote                 | Automation EDA TLS remote files         |          |    x     | false              |
| eda_type                       | Automation EDA node type                |          |    x     | hybrid             |
| eda_event_stream_prefix_path   | Automation EDA event stream prefix path |          |    x     | /eda-event-streams |
| eda_event_stream_url           | Automation EDA event stream URL         |          |    x     |                    |
| eda_workers                    | Automation EDA workers count            |          |    x     | 2                  |

### Automation Gateway

| Name                                         | Description                                | Required | Optional | Default            |
| -------------------------------------------- | ------------------------------------------ | -------- | -------- | -------------------|
| gateway_admin_password                       | Automation Gateway admin password          |     x    |          |                    |
| gateway_admin_user                           | Automation Gateway admin user              |          |    x     | admin              |
| gateway_main_url                             | Automation Gateway main URL                |          |    x     |                    |
| gateway_nginx_client_max_body_size           | Nginx maximum body size                    |          |    x     | 5m                 |
| gateway_nginx_disable_hsts                   | Disable Nginx HSTS                         |          |    x     | false              |
| gateway_nginx_disable_https                  | Disable Nginx HTTPS                        |          |    x     | false              |
| gateway_nginx_hsts_max_age                   | Nginx HSTS maximum age                     |          |    x     | 63072000           |
| gateway_nginx_http_port                      | Nginx HTTP port                            |          |    x     | 8083               |
| gateway_nginx_https_port                     | Nginx HTTPS port                           |          |    x     | 8446               |
| gateway_nginx_https_protocols                | Nginx HTTPS protocols                      |          |    x     | [TLSv1.2, TLSv1.3] |
| gateway_nginx_user_headers                   | Custom Nginx headers                       |          |    x     | []                 |
| gateway_pg_database                          | Postgresql Gateway database                |          |    x     | gateway            |
| gateway_pg_host                              | Postgresql Gateway host                    |     x    |          |                    |
| gateway_pg_password                          | Postgresql Gateway password                |     x    |          |                    |
| gateway_pg_port                              | Postgresql Gateway port                    |          |    x     | 5432               |
| gateway_pg_username                          | Postgresql Gateway user                    |          |    x     | gateway            |
| gateway_redis_disable_tls                    | Disable TLS Redis                          |          |    x     | false              |
| gateway_redis_host                           | Redis Gateway host                         |          |    x     |                    |
| gateway_redis_password                       | Redis Gateway password                     |          |    x     |                    |
| gateway_redis_port                           | Redis Gateway port                         |          |    x     | 6379               |
| gateway_redis_tls_cert                       | Automation Gateway redis TLS certificate   |          |    x     |                    |
| gateway_redis_tls_key                        | Automation Gateway redis TLS key           |          |    x     |                    |
| gateway_redis_username                       | Redis Gateway username                     |          |    x     | gateway            |
| gateway_secret_key                           | Automation Gateway secret key              |          |    x     |                    |
| gateway_tls_cert                             | Automation Gateway TLS certificate         |          |    x     |                    |
| gateway_tls_key                              | Automation Gateway TLS key                 |          |    x     |                    |
| gateway_tls_remote                           | Automation Gateway TLS remote files        |          |    x     | false              |
| gateway_grpc_server_processes                | Gateway auth server processes              |     x    |    x     | 5                  |
| gateway_grpc_server_max_threads_per_process  | Gateway auth server threads/process        |     x    |    x     | 10                 |
| gateway_grpc_auth_service_timeout            | Gateway auth server timeout                |     x    |    x     | 30s                |
| gateway_uwsgi_listen_queue_size              | Automation Gateway uwsgi listen queue size |          |    x     | 4096               |

### Automation Hub

| Name                           | Description                     | Required | Optional | Default            |
| ------------------------------ | ------------------------------- | -------- | -------- | ------------------ |
| hub_admin_password             | Automation Hub admin password   |     x    |          |                    |
| hub_galaxy_importer            | Automation Hub galaxy importer  |          |    x     |                    |
| hub_main_url                   | Automation Hub main URL         |          |    x     |                    |
| hub_nginx_client_max_body_size | Nginx maximum body size         |          |    x     | 20m                |
| hub_nginx_disable_hsts         | Disable Nginx HSTS              |          |    x     | false              |
| hub_nginx_disable_https        | Disable Nginx HTTPS             |          |    x     | false              |
| hub_nginx_hsts_max_age         | Nginx HSTS maximum age          |          |    x     | 63072000           |
| hub_nginx_http_port            | Nginx HTTP port                 |          |    x     | 8081               |
| hub_nginx_https_port           | Nginx HTTPS port                |          |    x     | 8444               |
| hub_nginx_https_protocols      | Nginx HTTPS protocols           |          |    x     | [TLSv1.2, TLSv1.3] |
| hub_nginx_user_headers         | Custom Nginx headers            |          |    x     | []                 |
| hub_pg_database                | Postgresql Hub database         |          |    x     | pulp               |
| hub_pg_host                    | Postgresql Hub host             |     x    |          |                    |
| hub_pg_password                | Postgresql Hub password         |     x    |          |                    |
| hub_pg_port                    | Postgresql Hub port             |          |    x     | 5432               |
| hub_pg_socket                  | Postgresql Hub unix socket      |          |    x     |                    |
| hub_pg_username                | Postgresql Hub user             |          |    x     | pulp               |
| hub_secret_key                 | Automation Hub secret key       |          |    x     |                    |
| hub_storage_backend            | Automation Hub storage backend  |          |    x     | file               |
| hub_tls_cert                   | Automation Hub TLS certificate  |          |    x     |                    |
| hub_tls_key                    | Automation Hub TLS key          |          |    x     |                    |
| hub_tls_remote                 | Automation Hub TLS remote files |          |    x     | false              |
| hub_workers                    | Automation Hub workers count    |          |    x     | 2                  |

#### Automation Hub - Shared Storage

Shared storage is required when installing more than one Automation Hub with `file` storage backend.
When installing a single instance of the Automation Hub, it is optional

| Name                       | Description                          | Required | Optional | Default      |
| -------------------------- | ------------------------------------ | -------- | -------- | ------------ |
| hub_shared_data_path       | Path to an NFS share with RWX access |    x     |          |              |
| hub_shared_data_mount_opts | Mount options for NFS share          |          |    x     | rw,sync,hard |

#### Automation Hub - Azure Blob Storage

When using Azure blob storage backend then `hub_storage_backend` needs to be set to `azure`.
The Azure container needs to exist before running the installer.

| Name                     | Description          | Required | Optional | Default |
| ------------------------ | -------------------- | -------- | -------- | ------- |
| hub_azure_account_key    | Azure account key    |    x     |          |         |
| hub_azure_account_name   | Azure account name   |    x     |          |         |
| hub_azure_container      | Azure container name |          |    x     | pulp    |
| hub_azure_extra_settings | Azure extra settings |          |    x     | {}      |

Extra parameters will need to be passed through an ansible `hub_azure_extra_settings` dictionary.

For example, you may set:

```yaml
hub_azure_extra_settings:
  AZURE_LOCATION: foo
  AZURE_SSL: True
  AZURE_URL_EXPIRATION_SECS: 60
```

The list of all possible configuration can be found [here](https://django-storages.readthedocs.io/en/latest/backends/azure.html#settings)

#### Automation Hub - S3 Storage

When using AWS S3 storage backend then `hub_storage_backend` needs to be set to `s3`.
The AWS S3 bucket needs to exist before running the installer.

| Name                  | Description           | Required | Optional | Default |
| --------------------- | --------------------- | -------- | -------- | ------- |
| hub_s3_access_key     | AWS S3 access key     |    x     |          |         |
| hub_s3_secret_key     | AWS S3 secret name    |    x     |          |         |
| hub_s3_bucket_name    | AWS S3 bucket name    |          |    x     | pulp    |
| hub_s3_extra_settings | AWS S3 extra settings |          |    x     | {}      |

Extra parameters will need to be passed through an ansible `hub_s3_extra_settings` dictionary.

For example, you may set:

```yaml
hub_s3_extra_settings:
  AWS_S3_MAX_MEMORY_SIZE: 4096
  AWS_S3_REGION_NAME: eu-central-1
  AWS_S3_USE_SSL: True
```

The list of all possible configuration can be found [here](https://django-storages.readthedocs.io/en/latest/backends/amazon-S3.html#settings)

#### Automation Hub - Postinstall

The hub postinstall allows one to create resources (collections, users, groups, etc..) after the hub deployment.

| Name                          | Description                            | Required | Optional | Default |
| ----------------------------- | -------------------------------------- | -------- | -------- | --------|
| hub_postinstall               | Enable Automation Hub postinstall      |          |     x    | false   |
| hub_postinstall_async_delay   | Postinstall delay between retries      |          |     x    | 1       |
| hub_postinstall_async_retries | Postinstall number of tries to attempt |          |     x    | 30      |
| hub_postinstall_dir           | Automation Hub postinstall directory   |          |     x    |         |
| hub_postinstall_ignore_files  | Automation Hub ignore files            |          |     x    | []      |
| hub_postinstall_repo_ref      | Automation Hub repository branch/tag   |          |     x    | main    |
| hub_postinstall_repo_url      | Automation Hub repository URL          |          |     x    |         |

The `hub_postinstall_repo_url` variable can be used to define the postinstall repository URL which may include
authentication information.

- `http(s)://<host>/<repo>.git` (public repository without http(s) authentication)
- `http(s)://<user>:<password>@<host>:<repo>.git` (private repository with http(s) authentication)
- `git@<host>:<repo>.git` (public/private repository with ssh authentication)

When using ssh based authentication, the installer doesn't configure anything (ssh key or so) for you and you need
to have everything configured on the installer node.

#### Automation Hub - Signing

By default, Automation Hub doesn't sign collections and containers.
It's possible to turn on this feature via the `hub_collection_signing` and/or `hub_container_signing` variables.
For collections and/or containers you'll need to provide a GPG key to sign the artifacts.

| Name                           | Description                                  | Required | Optional | Default           |
| ------------------------------ | -------------------------------------------- | -------- | -------- | ----------------- |
| hub_collection_auto_sign       | Enable Automation Hub collection auto sign   |          |    x     |      false        |
| hub_collection_signing         | Enable Automation Hub collection signing     |          |    x     |      false        |
| hub_collection_signing_key     | Automation Hub collection signing key        |          |    x     |                   |
| hub_collection_signing_pass    | Automation Hub collection signing passphrase |          |    x     |                   |
| hub_collection_signing_service | Automation Hub collection signing service    |          |    x     | ansible-default   |
| hub_container_signing          | Enable Automation Hub container signing      |          |    x     |      false        |
| hub_container_signing_key      | Automation Hub container signing key         |          |    x     |                   |
| hub_container_signing_pass     | Automation Hub container signing passphrase  |          |    x     |                   |
| hub_container_signing_service  | Automation Hub container signing service     |          |    x     | container-default |

Note that if the GPG key is protected by a passphrase then you need to provide it via the `hub_collection_signing_pass`
and/or `hub_container_signing_pass` variables.

### Database

| Name                            | Description                     | Required | Optional | Default       |
| ------------------------------- | ------------------------------- | -------- | -------- | ------------- |
| postgresql_admin_database       | Postgresql admin database       |          |    x     | postgres      |
| postgresql_admin_username       | Postgresql admin user           |          |    x     | postgres      |
| postgresql_admin_password       | Postgresql admin password       |     x    |          |               |
| postgresql_disable_tls          | Disable Postgresql TLS          |          |    x     | false         |
| postgresql_effective_cache_size | Postgresql effective cache size |          |    x     |               |
| postgresql_keep_databases       | Keep databases during uninstall |          |    x     | false         |
| postgresql_max_connections      | Postgresql max connections      |          |    x     | 1024          |
| postgresql_log_destination      | Postgresql log file location    |          |    x     | /dev/stderr   |
| postgresql_password_encryption  | Postgresql password encryption  |          |    x     | scram-sha-256 |
| postgresql_port                 | Postgresql port                 |          |    x     | 5432          |
| postgresql_shared_buffers       | Postgresql shared buffers       |          |    x     |               |
| postgresql_tls_cert             | Postgresql TLS certificate      |          |    x     |               |
| postgresql_tls_key              | Postgresql TLS key              |          |    x     |               |
| postgresql_tls_remote           | Postgresql TLS remote files     |          |    x     | false         |

### Receptor

| Name                         | Description                   | Required | Optional |   Default   |
| ---------------------------- | ----------------------------- | -------- | -------- | ----------- |
| receptor_disable_signing     | Disable receptor signing      |          |    x     |    false    |
| receptor_disable_tls         | Disable receptor TLS          |          |    x     |    false    |
| receptor_log_level           | Receptor loggging level       |          |    x     |     info    |
| receptor_mintls13            | Receptor TLS 1.3 minimal      |          |    x     |    false    |
| receptor_peers               | Receptor peers list           |          |    x     |     []      |
| receptor_port                | Receptor port                 |          |    x     |    27199    |
| receptor_protocol            | Receptor protocol             |          |    x     |     tcp     |
| receptor_signing_private_key | Receptor signing private key  |          |    x     |             |
| receptor_signing_public_key  | Receptor signing public key   |          |    x     |             |
| receptor_signing_remote      | Receptor signing remote files |          |    x     |    false    |
| receptor_tls_cert            | Receptor TLS certificate      |          |    x     |             |
| receptor_tls_key             | Receptor TLS key              |          |    x     |             |
| receptor_tls_remote          | Receptor TLS remote files     |          |    x     |    false    |
| receptor_type                | Receptor node type            |          |    x     |  execution  |

### Redis

| Name                         | Description                       | Required | Optional |   Default   |
| ---------------------------- | --------------------------------- | -------- | -------- | ----------- |
| redis_cluster_ip             | Redis cluster IP address          |          |    x     |             |
| redis_mode                   | Redis mode cluster or standalone  |          |    x     |   cluster   |

### Performance Co-Pilot Monitoring

| Name                         | Description                                             | Required | Optional |   Default   |
| ---------------------------- | ------------------------------------------------------- | -------- | -------- | ----------- |
| setup_monitoring             | Setup Performance Co-Pilot on AAP control plane nodes   |          |    x     |    false    |
| pcp_pmcd_port                | Port to serve Performance Metrics Collection Daemon on  |          |    x     |    44321    |
| pcp_pmproxy_port             | Port to serve Performance Metrics Proxy on              |          |    x     |    44322    |
| pcp_firewall_zone            | Firewall zone for pcp services                          |          |    x     |    public   |

The minimal configuration for running the containerized install will look like the following:

```yaml
---
controller_admin_password: foo
controller_pg_host: 127.0.0.1
controller_pg_password: bar
hub_admin_password: supersecret
hub_pg_host: 127.0.0.1
hub_pg_password: secretsuper
postgresql_admin_password: foobar
...

```

These variables can be put in a `vars.yml` and passed as `-e @vars.yml` to `ansible-playbook` command.
Otherwise, they can be put in the inventory. A sample inventory is included in the `samples` folder.

## Usage

You first need to create the ansible inventory file.
The current topology supports the following groups:
- `automationcontroller`
- `automationeda`
- `automationhub`
- `database`
- `execution_nodes`

```ini
[automationcontroller]
node.ansible.com

[automationhub]
node.ansible.com

[automationeda]
node.ansible.com

[database]
node.ansible.com
```

Note that `automationeda` is only available with AAP 2.4+ releases.

The same node can be used as `automationcontroller` and `database` or you can use a dedicated node
for each group.

```bash
$ ansible-playbook -i </path/to/inventory> ansible.containerized_installer.install
```

There are two ways to run the containerized installer:
- Online: The container images will be pulled from a registry
- Offline: The container images will be imported from a tarball

This workflow is controlled via the `bundle_install` variable.

### Disconnected registry
The installer does not manage installation of a disconnected registry.
If needed, you can use <https://github.com/quay/mirror-registry> tool, which will
install a containerized Quay registry.

### Online install

This is the default install scenario (`bundle_install: false`) and will try to pull the container images
from `registry.redhat.io` (which requires authentication).
As such you need to provide the registry username and password for authentication.

```yaml
---
registry_username: foo@ansible.com
registry_password: bar
...
```

As an alternative, you can use the internal registry (without authentication).

```yaml
---
registry_auth: false
registry_url: registry-proxy.engineering.redhat.com
registry_ns_aap: rh-osbs
registry_ns_rhel: rh-osbs
registry_tls_verify: false
controller_image: 'ansible-automation-platform-25-controller-rhel8:latest'
ee_minimal_image: 'ansible-automation-platform-25-ee-minimal-rhel8:latest'
ee_supported_image: 'ansible-automation-platform-25-ee-supported-rhel8:latest'
hub_image: 'ansible-automation-platform-25-hub-rhel8:latest'
hub_web_image: 'ansible-automation-platform-25-hub-web-rhel8:latest'
postgresql_image: 'rhel8-postgresql-15:latest'
redis_image: 'rhel8-redis-6:latest'
...
```

### Offline install

For offline installation, we need to export the container images from the registry  before running the installer.

```bash
$ ansible-playbook ansible.containerized_installer.bundle
```

Note: The default (un)compress tool is gzip but you can change it to pigz to reduce the execution time.

```bash
$ ansible-playbook ansible.containerized_installer.bundle -e container_compress=pigz
```

By default, the container images will be pulled from the public registry.
If you want to use the images from `registry.redhat.io` then you'll need to set extra variables to
that command.

```bash
$ ansible-playbook ansible.containerized_installer.bundle -e registry_auth=true -e registry_username=foo -e registry_password=bar
```

This command will create a `bundle/images` directory with all container images tarball (compressed).
You need to set `bundle_install: true` in your ansible configuration and `bundle_dir` with
the path the bundle directory (without the images subdirectory).

```bash
$ ansible-playbook -i </path/to/inventory> ansible.containerized_installer.install -e bundle_install=true -e bundle_dir=$(pwd)/bundle
```

If you need to pull container images from a different architecture than the local node then you can use the `container_image_arch`
variable.
By default, podman will pull the container images with the same architecture than the current host.
To download aarch64 container images from a x86_64 host then you can use the following command:

```bash
$ ansible-playbook ansible.containerized_installer.bundle -e container_image_arch=aarch64
```

### Backup

To backup a containerized deployment, execute the `backup.yml` playbook.

```bash
$ ansible-playbook -i </path/to/inventory> ansible.containerized_installer.backup
```

This will backup the important data deployed by the containerized installer such as:

- postgresql databases
- configuration files
- data files

By default, the backup directory on the ansible host will use ~/backups but this can be changed via the `backup_dir` variable.

### Restore

To restore a containerized deployment, execute the `restore.yml` playbook.

```bash
$ ansible-playbook -i </path/to/inventory> ansible.containerized_installer.restore
```

This will restore the important data deployed by the containerized installer such as:

- postgresql databases
- configuration files
- data files

By default, the backup directory on the ansible host will use ~/backups but this can be changed via the `backup_dir` variable.

### Uninstall

To uninstall a containerized deployment, execute the `uninstall.yml` playbook.

```bash
$ ansible-playbook -i </path/to/inventory> ansible.containerized_installer.uninstall
```

This will stop all systemd units and containers and then delete all resources used by the containerized installer
such as:

* config and data directories/files
* systemd unit files
* podman containers and images
* RPM packages

To keep container images, you can set the `container_keep_images` variable to true.

```bash
$ ansible-playbook -i </path/to/inventory> ansible.containerized_installer.uninstall -e container_keep_images=true
```

To keep postgresql databases, you can set the `postgresql_keep_databases` variable to true.

```bash
$ ansible-playbook -i </path/to/inventory> ansible.containerized_installer.uninstall -e postgresql_keep_databases=true
```

Note that you'll have to use the same django secret key values rather than the auto-generated ones.

## Access

The protocol and ports default values are:
* `https` protocol
* ports `80/443` for gateway

The Automation Gateway UI is available by default at:

```
https://<gateway node>:443
```
